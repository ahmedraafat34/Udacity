package com.example.ahamed.newsapp;

import android.app.LoaderManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<News>> {

    RecyclerView recyclerView;
    ProgressBar progressBar;
    TextView holder;
    NewsAdapter newsAdapter;


    private static final int LOADER_ID = 11;

    private static final String NEWS_URL = "http://content.guardianapis.com/search?";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        holder = findViewById(R.id.holder);
        progressBar = findViewById(R.id.progress_circular);

        setLoader();

    }



    void setLoader() {

        ConnectivityManager connectivityManager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected()) {
            Toast.makeText(getApplicationContext(), getString(R.string.no_internet), Toast.LENGTH_LONG).show();
            hideProgress();
            return;
        }

        android.app.LoaderManager loaderManager = getLoaderManager();
        loaderManager.initLoader(LOADER_ID, null, this);
    }

    void setData(List<News> news) {

        newsAdapter = new NewsAdapter(news, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(newsAdapter);

        if (news != null) {
            holder.setVisibility(View.INVISIBLE);

        } else {
            holder.setVisibility(View.VISIBLE);
        }


    }


    @Override
    public android.content.Loader<List<News>> onCreateLoader(int i, Bundle bundle) {
        showProgress();
        Uri baseUri = Uri.parse(NEWS_URL);
        Uri.Builder uriBuilder = baseUri.buildUpon();
        uriBuilder.appendQueryParameter("api-key", "test");

        return new NewsLoader(MainActivity.this, uriBuilder.toString());

    }

    @Override
    public void onLoadFinished(android.content.Loader<List<News>> loader, List<News> news) {
        setData(news);
        hideProgress();
    }

    @Override
    public void onLoaderReset(android.content.Loader<List<News>> loader) {

    }


    void showProgress() {
        progressBar.setVisibility(View.VISIBLE);
    }

    void hideProgress() {
        progressBar.setVisibility(View.INVISIBLE);
        holder.setVisibility(View.INVISIBLE);
    }


}
