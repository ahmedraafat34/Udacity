package com.example.ahamed.newsapp;

import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;


public class JsonUtils {
    private static final String LOG = JsonUtils.class.getSimpleName();

    private JsonUtils(){

    }

    public static List<News> getNews(String requestUrl){
        URL url = createUrl(requestUrl);
        String json_response  = null;
        try{
            json_response = makeHttpRequest(url);
            Log.i(LOG,json_response);
        } catch (IOException e){
            e.printStackTrace();
        }

        return extractFromJson(json_response);
    }

    private static URL createUrl(String StringUrl){
        URL url = null;
        try{
            url = new URL(StringUrl);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return url;
    }

    private static String makeHttpRequest(URL url) throws IOException{
        String jsonResponse = "";

        if(url==null){
            return jsonResponse;
        }

        HttpURLConnection httpURLConnection = null;
        InputStream inputStream = null;

        try{
            httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setReadTimeout(10000);
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.connect();

            if(httpURLConnection.getResponseCode() == 200){
                inputStream = httpURLConnection.getInputStream();
                jsonResponse = readFromString(inputStream);
            } else {
                Log.e(LOG,"ERRORCODE!!"+httpURLConnection.getResponseCode());
            }
        } catch (IOException e){
            e.printStackTrace();
        } finally {
            if(httpURLConnection != null){
                httpURLConnection.disconnect();
            }
            if(inputStream != null){
                inputStream.close();
            }
        }
        return jsonResponse;
    }

    private static String readFromString(InputStream inputStream) throws IOException{
        StringBuilder output = new StringBuilder();
        if (inputStream != null){
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
            while (line != null){
                output.append(line);
                line = reader.readLine();
            }
        }

        return output.toString();
    }

    private static ArrayList<News> extractFromJson(String newsJson){
        if(TextUtils.isEmpty(newsJson)){
            return null;
        }

        ArrayList<News> newsList = new ArrayList<>();

        try {

            JSONObject jsonObject = new JSONObject(newsJson);
            JSONArray jsonArray = jsonObject.getJSONObject("response").getJSONArray("results");

            for(int i=0;i<jsonArray.length();i++){

                JSONObject newsJsonObject = jsonArray.getJSONObject(i);

                String sectionName = newsJsonObject.getString("sectionName");
                String title = newsJsonObject.getString("webTitle");
                String date = newsJsonObject.getString("webPublicationDate");
                String webUrl = newsJsonObject.getString("webUrl");
                String pillarName = newsJsonObject.getString("pillarName");


                News news = new News(sectionName,title,webUrl,date,pillarName);

                newsList.add(news);
            }
        } catch (JSONException e){
            e.printStackTrace();
        }

        return newsList;
    }


}
