package com.example.ahamed.newsapp;




public class News {

    String sectionName;

    String wbTitle;

    String wbUrl;

    String date;

    String pillarNam;


    public News(String sectionName, String wbTitle, String wbUrl, String date, String pillarNam) {
        this.sectionName = sectionName;
        this.wbTitle = wbTitle;
        this.wbUrl = wbUrl;
        this.date = date;
        this.pillarNam = pillarNam;
    }

    public String getPillarNam() {
        return pillarNam;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public String getWbTitle() {
        return wbTitle;
    }

    public void setWbTitle(String wbTitle) {
        this.wbTitle = wbTitle;
    }

    public String getWbUrl() {
        return wbUrl;
    }

    public void setWbUrl(String wbUrl) {
        this.wbUrl = wbUrl;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


}
